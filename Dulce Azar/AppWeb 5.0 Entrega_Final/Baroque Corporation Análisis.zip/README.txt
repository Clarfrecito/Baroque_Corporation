README
Integrantes Baroque Corporation:
-Juan Freire
-Tomas Palumbo
-Sol Oliveti
-Marco Montarner
-Santino Solferino